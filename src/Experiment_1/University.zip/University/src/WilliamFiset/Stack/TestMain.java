package WilliamFiset.Stack;



public class TestMain {
    public static void main(String[] args) {

    }

}
