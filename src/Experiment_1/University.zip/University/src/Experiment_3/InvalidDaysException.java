package Experiment_3;

public class InvalidDaysException extends Exception{
}
