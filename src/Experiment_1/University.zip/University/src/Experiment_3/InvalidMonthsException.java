package Experiment_3;

public class InvalidMonthsException extends  Exception{
}
