package Experiment_3;

public class InvalidAmountException extends Exception{
}
