package Experiment_3;

public class InvalidAgeException extends Exception{


}
